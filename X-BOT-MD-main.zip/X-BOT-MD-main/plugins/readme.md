Myra File open aaki alle 
.
.
.
Ellam kitiyallo 
.
Ini odiko 🤣🖐🏻
