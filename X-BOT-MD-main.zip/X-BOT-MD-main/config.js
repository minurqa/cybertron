const fs = require('fs')
const chalk = require('chalk')



//-----------------------
// SESSION ID CONECTING 👇🏻
//-------------------------
module.exports = {
SESSION_ID: '' //Put your session id here
}
/*

 Other Configurations are down 👇🏻


*/
//---------------------------------
// Only use true/false
//---------------------------------
global.autoTyping = true //Auto typing...(true for on, false for off)
global.autoRecord = false // Auto recording...(true for on, false for off)
global.autoread = true // Auto Message read(true for on, false for off)
global.alwaysonline = true // Always Online(true for on, false for off)
global.statusread = true // Auto status read 🗿🖐🏻(true for on, false for off)
global.private = false// worktype(true for private, false for public)
global.autoreact = true// Auto react ( verum myra aah 🤣🙌🏻 )
global.autodlyt = true// Auto YouTube video downloader(true for on, false for off)
global.largethumb = "true" // for large thumbnail 
global.version = "1.1.1"
//---------------------------------
// Required variables
//---------------------------------
global.prefix = "." // use "" for removing prefix
global.ownername = " mc" // Bot Owner name
global.botname = "cybertron-ʙᴏᴛ-ᴍᴅ" //bot name
global.thumb = "https://imgur.com/a/1nOsf5A" // bot image overall
global.ownernumber = ["447893983991"] //SODO / OWNER NUMBER
global.caption = "_*ɢᴇɴᴇʀᴀᴛᴇᴅ ʙʏ cybertron-ʙᴏᴛ-ᴍᴅ*_" // Caption 
//---------------------------------
// Owner Mention Audio
//---------------------------------
global.ownermention = true // to turn off type false  || turn on type true 👌🏻
global.mtitle = "cybertron-Bot-Md" // mention tittle
global.mbody = "mc" // mention discription 
global.mthumb = 'https://imgur.com/a/1nOsf5A' // mention thumbnail 
global.murl = '
global.mentionaudio = ["https://i.imgur.com/h0mNy8p.mp4","https://i.imgur.com/zNWjhDn.mp4","https://i.imgur.com/Ya3325t.mp4","https://i.imgur.com/k4FE9mA.mp4","https://i.imgur.com/X5WGE9W.mp4","https://i.imgur.com/veoDgRH.mp4","https://i.imgur.com/CZ3eJgw.mp4","https://i.imgur.com/6QFiAoM.mp4","https://i.imgur.com/lAbt9ew.mp4"] //mention audios
//---------------------------------
// All in One Url ( you can add any url you want )
//---------------------------------
global.url = 'https://chat.whatsapp.com/F9Yg4rUErnHC26ocsg19ko' // mention url
//---------------------------------
// No need of editing ( Edit aaki oombanda 🗿🖐🏻) kuduthal edit aakiyal kolamm aayum myra 🖐🏻🤣
//---------------------------------
global.IMGBB_KEY = ["76a050f031972d9f27e329d767dd988f", "deb80cd12ababea1c9b9a8ad6ce3fab2", "78c84c62b32a88e86daf87dd509a657a"]
global.reactemoji = ['😨','😅','😂','😳','😎', '🥵', '😱', '🐦', '🙄', '🐤','🗿','🐦','🤨','🥴','😐','👆','😔', '👀','👎','🔥','💦','✂️','🍭'] // auto react emoji
global.sparky = ['☆','✼','　 ҉ ','❏','🍭','△'] // menu design's 
global.worktype = 'X BOT MD MODE' // Dont edit it 💉✨
