Ni eeh file open aakiyalle

so ........


  ninak andi illa 

}
