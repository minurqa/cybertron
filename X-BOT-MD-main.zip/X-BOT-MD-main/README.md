<p align="center"> 
      <h1 align="center">X BOT MD MD</h1>
  <a href="https://x-md-qr-elctro-wizard.koyeb.app">
   <img alt="ASWIN SPARKY" height="300" src="https://i.imgur.com/Q2UNwXR.jpg">
  </a>
</p>
   
<p align="center">

  <a aria-label="Join our chats" href="https://chat.whatsapp.com/JjzEUDkJgke1vPGK3GAvG6" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>

  
<p align="center">

  <a aria-label="Tutorial" href="https://youtu.be/SFiPGCRbe8A?si=vqMF-Z5jLBIVVPVR" target="_blank">
    <img alt="youtube" src="https://img.shields.io/badge/Tutorial-FF0000?style=for-the-badge&logo=youtube&logoColor=white" />
  
---

### FORK THIS REPO

1. Must Fork This Repo Before Deployment !
   <br> 
<a href="https://github.com/A-S-W-I-N-S-P-A-R-K-Y/X-BOT-MD/fork"><img title="FORK REPO" src="https://img.shields.io/badge/FORK REPO-h?color=black&style=for-the-badge&logo=stackshare"></a>


### SCAN QR

2. Scan the QR and get the creds
   <br>
<a href='https://x-md-qr-elctro-wizard.koyeb.app' target="_blank"><img alt='SCAN QR' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

#### DEPLOY TO REPLIT 

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://www.replit.com/' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit'/></a>

2. Now Deploy
    <br>
<a href='https://replit.com/@xmorohhh/X-BOT-MD' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-IMPORT-black?style=for-the-badge&logo=replit'/></a>

* Now fork it and enjoy 🗿🙌🏻
<br>

#### DEPLOY TO KOYEB 

1. If You don't have a account in koyeb. Create a account.
    <br>
<a href='https://app.koyeb.com/auth/signup' target="_blank"><img alt='koyeb' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=koyeb'/></a>

2. Get [Koyeb api key](https://app.koyeb.com/account/api)

3. Now Deploy
    <br>
<a href='https://app.koyeb.com/apps/new/import-project' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=koyeb'/></a>

#### DEPLOY TO HEROKU ( WASTE 😹 )

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku'/></a>

2. Now Deploy
    <br>
<a href='https://chat.whatsapp.com/JjzEUDkJgke1vPGK3GAvG6' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku'/></a>


#### DEPLOY ON CYCLIC

1. If You don't have a account in Cyclic. Create a account.
    <br>
<a href='https://cyclic.sh' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=microsoft'/></a>

2. Now Deploy
    <br>
<a href='https://cyclic.sh' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=windows'/></a>


#### DEPLOY ON RENDER

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://dashboard.render.com' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=render'/></a>

2. Now Deploy
    <br>
<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render'/></a>

#### DEPLOY ON MOGENIUS

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://mogenius.com' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=genius'/></a>

2. Now Deploy
    <br>
<a href='https://mogenius.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=genius'/></a>


#### DEPLOY ON COOLIFY

1. If You don't have a account in Coolify. Create a account.
    <br>
<a href='https://coolify.io/' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=c'/></a>

2. Now Deploy
    <br>
<a href='https://coolify.io/' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=C'/></a>


#### DEPLOY ON UFFIZZI

1. If You don't have a account in Uffizzi. Create a account.
    <br>
<a href='https://www.uffizzi.com/' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=x'/></a>

2. Now Deploy
    <br>
<a href='https://www.uffizzi.com/' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=x'/></a>

---
## IN DEVLOPMENT { Stay Turned... } 🙂🙌🏻 

#### DEPLOY ON RAILWAY

1. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=railway'/></a>

2. Now Deploy
    <br>
<a href='https://railway.app' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=railway'/></a>

---

## 🗿 Why Should You Use X-BOT-MD as your Base :

      
<details close>
<summary>Read More</summary>

<br>

- X-BOT-MD is a `fully open source 😹🖐🏻` bot which means `no copyright`.
- X-BOT-MD is a `multi character bot` which means you can `change bot's character` to any of the 8 added characters or add more characters by yourself.
- X-BOT-MD is a `multi database bot Eg : MongoVedi,PostgreMYR,VediDB` which means you can use 3 different databases at the same time.
- X-BOT-MD is a `multi mode` bot which means you can use it in `Self / Public / Private` mode.

  </details> 
    
---

#### Thanks To
* [`EX-KRIZ`](https://github.com/EX-KRIZ)
* [`KICHUX`](https://github.com/TOXIC-KICHUX)
* [`VIPER`](https://github.com/Viper-X0)
* [`INRL`](https://github.com/inrl-official)
* [`ABU`](https://github.com/Afx-Abu)
